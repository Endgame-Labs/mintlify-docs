# Google Account Logins

## Authentication

While we can primarily authenticate users via Salesforce OAuth, we also allow for Google Auth if you have Google Accounts. This makes it so users without Salesforce seats can also login using Google’s robust authentication framework.

Users who login using this method will also have the same Endgame experience as those who use Salesforce.

If access using Google Accounts is needed, please send a request to support@endgame.io, along with the email addresses you’re requesting for access.

Make sure you’ve informed these users beforehand, because as part of the authentication process, their GMail account will receive an email from us for verification. This is for security and safety purposes, to make sure they are in control of the account.