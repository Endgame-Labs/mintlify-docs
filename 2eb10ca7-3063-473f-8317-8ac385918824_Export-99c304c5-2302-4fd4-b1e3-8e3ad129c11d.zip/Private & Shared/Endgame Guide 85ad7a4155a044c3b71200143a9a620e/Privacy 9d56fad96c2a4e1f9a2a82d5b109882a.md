# Privacy

You can find our privacy policy at [https://www.endgame.io/privacy](https://www.endgame.io/privacy).

For data deletion requests, please email the details of the request to [privacy@endgame.io](mailto:privacy@endgame.io).